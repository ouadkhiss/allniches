<?php 

//-------------------------------------//
// -- mode 1 khedam l ay CPA Network --// 
// -- mode 2 khedam CpaBuild Network --// 
// -- mode 3 hada l mokhtari3in hhhh --// 
//-------------------------------------//

	$mode= '3';  

	//----- Mode Mode 1 : Link -----//
	$cpa_url  = 'https://cbldc.io/f1ae36c';
		
	//----- Mode 2 : CpaBuild locker -----//
	$cpabuild_it  = '706533';
	$cpabuild_key  = '832b0';
		
	//----- Mode 3 : API MODE - NO LINK -----//
	$cpabuild_api  = '04a0b6138ce4c839e24294035d3b1f23';
	$cpabuild_user_id  = '61520';
	
	//----- Tracking - Google Analytics -----//	
	$channel_id = 'UCcsZV5NIQiayPBFwsi2J8EA';
	
	//----- Tracking - Google Analytics -----//
	$analytics_code = "a1234a7e-1";
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>Win a brand new Airpods Pro</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="Enter our time-limited give-away and Airpods Pro Free in any color you want!" />    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="icon" type="image/ico" href="img/favicon.ico" />
	<link rel="icon" type="image/png" sizes="16x16" href="img/favicon-16x16.png">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="theme-color" content="#ffffff">
    <meta property="og:image" content="img/iphone.png"/>
	<link href='https://fonts.googleapis.com/css?family=Raleway:300,400,700' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <link href="css/fancySelect.css" rel="stylesheet" />
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/sweet-alert.css" rel="stylesheet" />
    <link href="css/animate.css" rel="stylesheet" />
    <link href="css/magnific-popup.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.6/themes/vader/jquery-ui.css" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>	
	<script type="text/javascript" src="js/flipcounter.min.js"></script>	
	<link rel="stylesheet" type="text/css" href="css/counter.css" />
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $analytics_code ; ?>"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', '<?php echo $analytics_code ; ?>');
    </script>
</head>
<body>

	<div id="human-verification" class="generator-verification mfp-hide white-popup-block">
        <div class="row">
            <div class="col-md-12">
                <div class="section_heading text-center">
                    <h1>Human Verification</h1>
                </div>
            </div>
        </div>
        <div class="row">
            <div id="floatBarsG">
                <div id="floatBarsG_1" class="floatBarsG"></div>
                <div id="floatBarsG_2" class="floatBarsG"></div>
                <div id="floatBarsG_3" class="floatBarsG"></div>
                <div id="floatBarsG_4" class="floatBarsG"></div>
                <div id="floatBarsG_5" class="floatBarsG"></div>
                <div id="floatBarsG_6" class="floatBarsG"></div>
                <div id="floatBarsG_7" class="floatBarsG"></div>
                <div id="floatBarsG_8" class="floatBarsG"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-center offwrap">	
                <center>
				<p>Choose and Complete one of the offers that appear below on your screen to finish human verification</span>
						<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
						<script type="text/javascript">
							$(function() {
								$.getJSON("http://cpabuild.com/public/offers/feed.php?user_id=<?php echo $cpabuild_user_id ; ?>&api_key=<?php echo $cpabuild_api ; ?>&s1=&s2=&callback=?",
									function(offers){
										var html = '';
										var numOffers=5;
										offers=offers.splice(0,numOffers);
										$.each(offers, function(key, offer){
											html += '<div class="offer_holder" ><img class="offer_img" src="https://image.flaticon.com/icons/png/512/23/23656.png" /><a class="offer_url" href="'+offer.url+'" target="_blank" title="'+offer.conversion+'">'+offer.anchor+'</a></div>';
										});
										$("#offerContainer").append(html);
									});
							});
						</script>
						<div class="offer_container" id="offerContainer"></div>
				</center>
            </div>
		<div class="col-md-12 col-sm-12 counterwrapper">
			<div class="centerlivecounter" >
				<h3>Real-Time visitors in this step</h3>
			</div>
			<div class="livecounter" >
				<div class="livevisitors" id="c5"></div>
			</div>
			<script type="text/javascript">
				var myCounter = new flipCounter('c5', {value:322, inc:7, pace:1000, auto:true});
			</script>
		</div>	
        </div>
    </div>
	
	<header>
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<img class="img-responsive logo-img" src="img/header-logo.png">
					<h1>Win Free <span>Airpods Pro</span></h1>
					<p>Sign up now to receive a Free Airpods Pro!</p>
					<a class="header-entry-button scroll-me" href="#enter-give-away-now">
						<img class="header-button-img" src="img/header-button-img.png">
							Airpods Pro for you &nbsp; &nbsp;
						<span class="button-subtext">Sign Up Now</span>
					</a>				
				</div>
				<div class="col-md-6">
					<img class="img-responsive parallaxme header-img-right" src="img/header-img-right-1.png">
				</div>
			</div>	
		</div>	
	</header>
	<section class="section-first">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<div class="description-col description-col-1 make-me-same-height-1">
						<i class="icon-phone"></i>
						<h3>Magically Connected</h3>						
						<p>Just like AirPods, AirPods Pro connect magically to your iPhone or Apple Watch.</p>
					</div>
					<div class="description-col description-col-2 make-me-same-height-2">
						<i class="icon-speedometer"></i>
						<h3>Power and Battery</h3>						
						<p>The Wireless Charging Case delivers more than 24 hours of battery life to keep you and your AirPods Pro on the go. </p>
					</div>
				</div>
				<div class="col-md-4 section-first-mid-img-wrapp">
					<img class="img-responsive mid-img-first" src="img/section-first-mid-img-1.png">
					<img class="img-responsive mid-img-overlay" src="img/section-first-mid-img-2.png">
				</div>
				<div class="col-md-4">
					<div class="description-col description-col-3 make-me-same-height-1">
						<i class="icon-camera"></i>
						<h3>Super Water Resistant</h3>						
						<p>Designed to keep up with you, AirPods Pro are sweat and water resistant</p>
					</div>
					<div class="description-col description-col-4 make-me-same-height-2">
						<i class="icon-scope"></i>
						<h3>Full Control</h3>						
						<p>Use the force sensor to easily control music and calls, and switch between Active Noise Cancellation and Transparency mode.</p>						
					</div>
				</div>
			</div>
		</div>	
	</section>
	<section class="section-second">
		<div class="container">
			<div id="enter-give-away-now" class="row phone-select-row">		
				<div class="step1 marker_show">
					<h1><span>AirPods Pro Beta Tester</span>Choose your Color</h1>
					<div class="col-md-3 col-sm-6 next">
						<a href="javascript:void(0)" class="color-select-button color-select-button_1">
							<img class="img-responsive img-color-select" src="img/select-phone-img-1.png">
							<span>Black</span>
						</a>
					</div>
					<div class="col-md-3 col-sm-6 next">
						<a href="javascript:void(0)" class="color-select-button color-select-button_2">
							<img class="img-responsive img-color-select" src="img/select-phone-img-2.png">
							<span>White</span>
						</a>
					</div>
					<div class="col-md-12 col-sm-12 counterwrapper">
						<div class="centerlivecounter" >
							<h3>Real-Time visitors in this step</h3>
						</div>
						<div class="livecounter" >
							<div class="livevisitors" id="c1"></div>
						</div>
						<script type="text/javascript">
							var myCounter = new flipCounter('c1', {value:92425, inc:217, pace:1000, auto:true});
						</script>
					</div>
				</div>
				
				<div class="step2 marker_show" style="display: none;">
					<h1><span>AirPods Pro Give-Away</span>Choose your type</h1>
					<div class="col-sm-4 next">
						<a href="javascript:void(0)" class="capacity-select-button color-select-capacity_1">
							<span class="gb-amount">N <span class="gb-sign"> Type </span></span>
							<div class="capacity-info">
								<span class="reg-price"><span class="price-label">Left in stock:</span> 09</span>
								<span class="reg-price"><span class="price-label">Regular price:</span> $249,00</span>
								<span class="your-price"><span class="price-label">Your price:</span> $0,00</span>
							</div>	
						</a>
					</div>
					<div class="col-sm-4 next">
						<a href="javascript:void(0)" class="capacity-select-button color-select-capacity_1">
							<span class="gb-amount">C <span class="gb-sign"> Type </span></span>
							<div class="capacity-info">
								<span class="reg-price"><span class="price-label">Left in stock:</span> 07</span>
								<span class="reg-price"><span class="price-label">Regular price:</span> $349.00$</span>
								<span class="your-price"><span class="price-label">Your price:</span> $0,00</span>
							</div>	
						</a>
					</div>
					<div class="col-md-12 col-sm-12 counterwrapper">
						<div class="centerlivecounter" >
							<h3>Real-Time visitors in this step</h3>
						</div>
						<div class="livecounter" >
							<div class="livevisitors" id="c2"></div>
						</div>
						<script type="text/javascript">
							var myCounter = new flipCounter('c2', {value:41725, inc:47, pace:1000, auto:true});
						</script>
					</div>
				</div>
				<div class="step3 marker_show" style="display: none;">
					<h1><span>AirPods Pro Beta Tester</span>Subscribe to win</h1>
					<a class="ytb" id="user-email-submit" target="_blank" href="http://www.youtube.com/channel/<?php echo $channel_id ;?>?sub_confirmation=1" data-diff='1'><i class="fa fa-youtube" aria-hidden="true"></i> Subscribe</a>
						<span class="email-info-notice">
							Please <b>Subscribe</b> to our channel by clicking Subscribe button,
								<br>
							then <b>GO BACK TO THIS PAGE AND CLICK NEXT BUTTON </b>
								<br>
						</span>
						<span class="email-info-notice">
							Every entry will be checked manually.
								<br>
							Any bot activity will not be allowed.
						</span>
					<a class="contest-entry-button run_loading" ><i class="fa fa-arrow-circle-right"></i> Next</a>	
					<div class="col-md-12 col-sm-12 counterwrapper">
						<div class="centerlivecounter" >
							<h3>Real-Time visitors in this step</h3>
						</div>
						<div class="livecounter" >
							<div class="livevisitors" id="c3"></div>
						</div>
						<script type="text/javascript">
							var myCounter = new flipCounter('c3', {value:19341, inc:27, pace:1000, auto:true});
						</script>
					</div>
				</div>	
				<div class="step4 marker_show" style="display: none;">
					<center>
						<div id="floatBarsG">
							<div id="floatBarsG_1" class="floatBarsG"></div>
							<div id="floatBarsG_2" class="floatBarsG"></div>
							<div id="floatBarsG_3" class="floatBarsG"></div>
							<div id="floatBarsG_4" class="floatBarsG"></div>
							<div id="floatBarsG_5" class="floatBarsG"></div>
							<div id="floatBarsG_6" class="floatBarsG"></div>
							<div id="floatBarsG_7" class="floatBarsG"></div>
							<div id="floatBarsG_8" class="floatBarsG"></div>
						</div>
					</center>
					<div class="congrats-wrapper">
						<h3 class="run_loading_1 main_review">Checking selected Color Stock Value...</h3>
						<h3 class="run_loading_2" style="display: none;">Checking selected Type Stock Value...</h3>    
						<h3 class="run_loading_3" style="display: none;">Checking double previous attempts...</h3>
						<h3 class="run_loading_4" style="display: none;">Processing your request...</h3>
						<div class="run_loading_5" style="display: none;">
							<div class="cg-outer-wrap">
								<div class="cg-wrap">
									<h3>Congratulations, you're qualified to become an AirPods Pro Beta Tester</h3>
								</div>
							</div>
							<p class="note1">Due to large amount of duplicate entries and abuse of our Beta Tester program, you are required to complete <strong>Human Verification</strong> by clicking a button below.</p>
							<p class="note3"><strong>Note:</strong> Your application will not be submited untill you complete human verification!</p>
						</div>		
						<ul class="done_marker">
							<li class="thank_for_close" style="display: none;">Selected color is in stock.</li>						
							<li class="li_run_loading_1" style="display: none;">Selected Type is in stock.</li>
							<li class="li_run_loading_2" style="display: none;">No previous attempts found.</li>
							<li class="li_run_loading_4" style="display: none;">You qualify to participate in our give-away!</li>
						</ul>
						<div class="show_end" style="display: none;">
							<div class="countdown-wrap">You have 
								<span id="javascript_countdown_time"></span> 
								to complete human verification or your spot will be given to someone else.
							</div>
							<script type="text/javascript">
								var CPABUILDSETTINGS={"it":<?php echo $cpabuild_it ; ?>,"key":"<?php echo $cpabuild_key ; ?>"};
							</script>
							<script src="https://cpabuild.com/public/external/locker.js"></script>
							<?php if ($mode == 1) { ?>
								<a href="<?php echo $cpa_url ; ?>"><img src="img/hv.png" alt="Freeiphone"></a>
							<?php } elseif ($mode == 2) { ?>
								<a href="#" onclick="CPABuildLock()" > <img src="img/hv.png" alt="Freeiphone"></a>
							<?php } else { ?>
								<a class="human-verification-button" href="#human-verification"><img src="img/hv.png" alt="Freeiphone"></a>
							<?php } ?>
							<div class="col-md-12 col-sm-12 counterwrapper">
								<div class="centerlivecounter" >
									<h3>Real-Time visitors in this step</h3>
								</div>
								<div class="livecounter" >
									<div class="livevisitors" id="c4"></div>
								</div>
								<script type="text/javascript">
									var myCounter = new flipCounter('c4', {value:11322, inc:9, pace:1000, auto:true});
								</script>
							</div>							
						</div>

					</div>	
				</div>
			</div>
		</div>
	</section>
	
	<section class="custom-social-proof">
		<div class="custom-notification">
		  <div class="custom-notification-container">
			<div class="custom-notification-image-wrapper">
			  <img src="img/winner.png">
			</div>
			<div class="custom-notification-content-wrapper">
			  <p class="custom-notification-content">
				<span id="winner_name"></span> Has just won <b>Free Airpods Pro</b> 2019
				<small id="winner_date" ></small>
			  </p>
			</div>
		  </div>
		  <div class="custom-close"></div>
		</div>
	</section>	
	<script>
		var winnername = document.getElementById("winner_name");
		var winnerdate = document.getElementById("winner_date");
		var winner_name = ["Mm.Alen", "Mr.Parcker", "Mr.Jhon"];
		var winner_date = ["1 hours ago", "3 hours ago", "6 hours ago"];	
		var counter = 0;	
		var inst = setInterval(change, 6000);
		function change() {	 
		$(".custom-social-proof").stop().slideToggle(150); 
			winnername.innerHTML = winner_name[counter];
			counter++;
			if (counter >= winner_name.length) {
				counter = 0;
			}
			winnerdate.innerHTML = winner_date[counter];
			counter++;
			if (counter >= winner_date.length) {
				counter = 0;
			}
		}
		$(".custom-close").click(function() {
			$(".custom-social-proof").stop().slideToggle('slow');
		});	
	</script>
	<footer>
		<div class="container">
			<div class="policy-links">
				<a class="popup-contact popup-link" href="#contact-us">Contact Us</a><span class="pp-sep"> |</span>
				<a class="popup-tos popup-link" href="#terms-of-service">Terms of Service</a><span class="pp-sep"> |</span>
				<a class="popup-pp popup-link" href="#privacy-policy">Privacy Policy</a>
			</div>
			<p>All trademarks, service marks, trade names, trade dress, product names and logos appearing on the site are the property of their respective owners.</p>
		</div>	
	</footer>
	<div id="terms-of-service" class="tos-popup-wrapper popup-wrapper mfp-hide white-popup-block">
		<div class="row">
            <div class="col-md-12">
				<h1>Terms of service</h1>
				<h2>Age requirement</h2>
				<p>You must be at least 18 years of age to use this Website. By using this Website and by agreeing to this Agreement you warrant and represent that you are at least 18 years of age.</p>
				<h2>Backups</h2>
				<p>We are not responsible for Content residing on the Website. In no event shall we be held liable for any loss of any Content. It is your sole responsibility to maintain appropriate backup of your Content. Notwithstanding the foregoing, on some occasions and in certain circumstances, with absolutely no obligation, we may be able to restore some or all of your data that has been deleted as of a certain date and time when we may have backed up data for our own purposes. We make no guarantee that the data you need will be available.</p>
				<h2>Links to other websites</h2>
				<p>Although this Website may be linked to other websites, we are not, directly or indirectly, implying any approval, association, sponsorship, endorsement, or affiliation with any linked website, unless specifically stated herein. We are not responsible for examining or evaluating, and we do not warrant the offerings of, any businesses or individuals or the content of their websites. We do not assume any responsibility or liability for the actions, products, services and content of any other third parties. You should carefully review the legal statements and other conditions of use of any website which you access through a link from this Website. Your linking to any other off-site pages or other websites is at your own risk.</p>
				<h2>Advertisements</h2>
				<p>During use of the Website, you may enter into correspondence with or participate in promotions of advertisers or sponsors showing their goods or services through the Website. Any such activity, and any terms, conditions, warranties or representations associated with such activity, is solely between you and the applicable third-party. We shall have no liability, obligation or responsibility for any such correspondence, purchase or promotion between you and any such third-party.</p>
			</div>
		</div>
	</div>
	<div id="privacy-policy" class="pp-popup-wrapper popup-wrapper mfp-hide white-popup-block">
		<div class="row">
            <div class="col-md-12">
				<h1>Privacy policy</h1>
				<h2>Collection of personal information</h2>
				<p>We receive and store any information you knowingly provide to us when you fill any online forms on the Website.  You can choose not to provide us with certain information, but then you may not be able to take advantage of some of the Website's features.</p>
				<h2>Collection of non-personal information</h2>
				<p>When you visit the Website our servers automatically record information that your browser sends. This data may include information such as your computer's IP address, browser type and version, operating system type and version, language preferences or the webpage you were visiting before you came to our Website, pages of our Website that you visit, the time spent on those pages, information you search for on our Website, access times and dates, and other statistics.</p>
				<h2>Cookies</h2>
				<p>The Website uses "cookies" to help personalize your online experience. A cookie is a text file that is placed on your hard disk by a web page server. Cookies cannot be used to run programs or deliver viruses to your computer. Cookies are uniquely assigned to you, and can only be read by a web server in the domain that issued the cookie to you. We may use cookies to collect, store, and track information for statistical purposes to operate our Website and Services. You have the ability to accept or decline cookies. Most web browsers automatically accept cookies, but you can usually modify your browser setting to decline cookies if you prefer. If you choose to decline cookies, you may not be able to fully experience the features of the Website and Services.</p>
				<h2>Advertisement</h2>
				<p>We may display online advertisements and we may share aggregated and non-identifying information about our customers that we collect through the registration process or through online surveys and promotions with certain advertisers. We do not share personally identifiable information about individual customers with advertisers. In some instances, we may use this aggregated and non-identifying information to deliver tailored advertisements to the intended audience.</p>
			</div>
		</div>
	</div>
	<div id="contact-us" class="contact-popup-wrapper popup-wrapper mfp-hide white-popup-block">
		<h1>Send us a message</h1>
		<div class="contact-form-wrapper">
			<form role="form" id="contactForm" data-toggle="validator" class="shake">
				<div class="row">
					<div class="form-group col-sm-6">
						<label for="name" class="h4">Name</label>
						<input type="text" class="form-control" id="name" placeholder="Enter name" required data-error="NEW ERROR MESSAGE">
						<div class="help-block with-errors"></div>
					</div>
					<div class="form-group col-sm-6">
						<label for="email" class="h4">Email</label>
						<input type="email" class="form-control" id="email" placeholder="Enter email" required>
						<div class="help-block with-errors"></div>
					</div>
				</div>
				<div class="form-group">
					<label for="message" class="h4 ">Message</label>
					<textarea id="message" class="form-control" rows="5" placeholder="Enter your message" required></textarea>
					<div class="help-block with-errors"></div>
				</div>
				<button type="submit" id="form-submit" class="btn btn-success btn-lg pull-right ">Submit</button>
				<div id="msgSubmit" class="h3 text-center hidden"></div>
				<div class="clearfix"></div>
			</form>
		</div>
	</div>	


	<div id="thank-you" class="pp-popup-wrapper popup-wrapper mfp-hide">
		<h1>Thank You For Participating</h1>
		<p> Your entry has been automatically accepted. A manual check will verify whether all the steps were completed before submitting your entry. If you haven't shared
		the giveaway yet then please do it or else your entry will be discarded. The giveaway winners will be announced 20 days after release of iPhone 11. We hope that you do win. </p>
	</div>
    <script type="text/javascript" src="js/main.js"></script>
    <script type="text/javascript" src="js/validator.min.js"></script>
	<script type="text/javascript" src="js/sweet-alert.min.js"></script>
	<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>	
	<script type="text/javascript">
		var javascript_countdown = function () {
			var time_left =  600; 
			var keep_counting = 1;
			var no_time_left_message = 'few minutes';
			function countdown() {
				if(time_left < 2) {
					keep_counting = 0;
				}
				time_left = time_left - 1;
			}
			function add_leading_zero( n ) {
				if(n.toString().length < 2) {
					return '0' + n;
				} else {
					return n;
				}
			}
			function format_output() {
				var hours, minutes, seconds;
				seconds = time_left % 60;
				minutes = Math.floor(time_left / 60) % 60;
				hours = Math.floor(time_left / 3600);   
				seconds = add_leading_zero( seconds );
				minutes = add_leading_zero( minutes );
				hours = add_leading_zero( hours );
				return minutes + ' minutes and ' + seconds + ' seconds';
			}
			function show_time_left() {
				document.getElementById('javascript_countdown_time').innerHTML = '<span>' + format_output() + '</span>';//time_left;
			}
			function no_time_left() {
				document.getElementById('javascript_countdown_time').innerHTML = no_time_left_message;
			}
			return {
				count: function () {
					countdown();
					show_time_left();
				},
				timer: function () {
					javascript_countdown.count();
					if(keep_counting) {
						setTimeout("javascript_countdown.timer();", 1000);
					} else {
						no_time_left();
					}
				},
				init: function (n) {
					time_left = n;
					javascript_countdown.timer();
				}
			};
		}();
		javascript_countdown.init(900);
	</script>	
</body>
</html>